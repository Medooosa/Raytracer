# periode-1---graphics-group-24
periode-1---graphics-group-24 created by GitHub Classroom

Functionaliteiten UI:
  - Weergeven van de FPS
  - Scene veranderen
  - Skybox veranderen
  - Resolutie veranderen
  - Light bounces veranderen

Functionaliteiten raytracer:
  - Weergeven van 3D basis vormen (Box, Sphere en Plane)
  - Reflectie weergeven op basis van een reflectie hoeveelheit
  - Light diffuse weergeven
  
Overige functionaliteiten:
  - Het project is OOP geprogrameerd.
  - Men kan makkelijk in de code nieuwe Scenes aanmaken.
  - Men kan makkelijk nieuwe objecten toevoegen aan de scenes.
